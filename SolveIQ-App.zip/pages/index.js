import React, { useState } from 'react';

export default function Home() {
  const [problem, setProblem] = useState('');
  const [solution, setSolution] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSolve = async () => {
    if (!problem.trim()) return;
    setLoading(true);
    setSolution('');

    try {
      const res = await fetch('/api/solve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ problem }),
      });

      const data = await res.json();
      setSolution(data.solution);
    } catch (err) {
      setSolution('Something went wrong.');
    }

    setLoading(false);
  };

  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>SolveIQ</h1>
      <textarea
        value={problem}
        onChange={(e) => setProblem(e.target.value)}
        placeholder="Describe your problem..."
        rows={5}
        style={{ width: '100%', marginBottom: '1rem' }}
      />
      <button onClick={handleSolve} disabled={loading}>
        {loading ? 'Solving...' : 'Get Solution'}
      </button>
      {solution && <pre style={{ marginTop: '1rem' }}>{solution}</pre>}
    </div>
  );
}
